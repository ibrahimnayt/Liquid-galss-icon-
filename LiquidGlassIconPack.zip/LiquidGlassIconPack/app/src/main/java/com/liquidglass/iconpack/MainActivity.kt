package com.liquidglass.iconpack

import android.os.Bundle
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // كل الأيقونات المتوفرة في الحزمة — تُعرض هنا للمعاينة فقط
    private val icons = listOf(
        R.drawable.ic_wifi, R.drawable.ic_bluetooth, R.drawable.ic_flashlight, R.drawable.ic_battery,
        R.drawable.ic_settings, R.drawable.ic_phone, R.drawable.ic_camera, R.drawable.ic_messages,
        R.drawable.ic_music, R.drawable.ic_calendar, R.drawable.ic_clock, R.drawable.ic_weather,
        R.drawable.ic_mail, R.drawable.ic_airplane, R.drawable.ic_dnd, R.drawable.ic_lock
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val grid = findViewById<GridLayout>(R.id.iconGrid)
        val sizePx = (76 * resources.displayMetrics.density).toInt()
        val marginPx = (6 * resources.displayMetrics.density).toInt()

        icons.forEach { resId ->
            val iv = ImageView(this)
            val params = GridLayout.LayoutParams()
            params.width = sizePx
            params.height = sizePx
            params.setMargins(marginPx, marginPx, marginPx, marginPx)
            iv.layoutParams = params
            iv.setImageResource(resId)
            iv.setBackgroundResource(R.drawable.bg_glass_card)
            iv.setPadding(sizePx / 5, sizePx / 5, sizePx / 5, sizePx / 5)
            grid.addView(iv)
        }

        val applyButton = findViewById<View>(R.id.applyButton)
        val instructions = findViewById<TextView>(R.id.instructionsBody)
        applyButton.setOnClickListener {
            instructions.visibility =
                if (instructions.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }
}
